from django.apps import AppConfig


class UpperConfig(AppConfig):
    name = 'upper'
